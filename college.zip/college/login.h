#ifndef LOGIN_H
#define LOGIN_H

int login();

#endif // LOGIN_H 