#ifndef DELETE_H
#define DELETE_H

void delete_student();

#endif // DELETE_H 