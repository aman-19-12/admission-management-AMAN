#ifndef VIEW_H
#define VIEW_H

void view_students();

#endif // VIEW_H 