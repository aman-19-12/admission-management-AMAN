#ifndef MODIFY_H
#define MODIFY_H

void modify_student();

#endif // MODIFY_H 