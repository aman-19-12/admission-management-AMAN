#ifndef ADD_H
#define ADD_H

void add_student();

#endif // ADD_H 