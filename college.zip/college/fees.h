#ifndef FEES_H
#define FEES_H

void calculate_fee();

#endif // FEES_H 