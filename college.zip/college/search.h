#ifndef SEARCH_H
#define SEARCH_H

void search_student();

#endif // SEARCH_H 